package pl.cyfrogen.budget.exceptions;

public class NumberRangeException extends Exception {
    public NumberRangeException(String text) {
        super(text);
    }
}
