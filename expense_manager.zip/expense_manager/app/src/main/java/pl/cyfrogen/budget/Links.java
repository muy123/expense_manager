package pl.cyfrogen.budget;

public class Links {
    public static String PRIVACY_POLICY_LINK="https://github.com/jakubdybczak/budgetto/blob/master/PRIVACY_POLICY.md";
}
